jQuery.sap.declare("model.Config");
/**	Store Model Configuration, 
 * change details to your Gateway system
 */
model.Config = {
	getUser : function () {
		return "developer";
	},

	getPwd : function () {
		return "ch4ngeme";
	},

	getHost  : function () {	
		return "http://wdflbmd6865.secondphase.com.au:50000";
	},

	getServiceUrl : function () {	
		var sUrl = this.getHost() + "/sap/opu/odata/sap/ZGWSAMPLE_SRV/";
		return this.getUrl(sUrl);
	},
	
	/** For local testing bypass the browsers security settings that doesn't allowing 	
	 *  AJAX calls across domains and use the provided proxy
	 *  eg proxy/http/<server>:port/<service>
	 * @param sServiceUrl
	 * @returns
	 */
	getUrl : function (sServiceUrl) {
		var sOrigin = window.location.protocol + "//" + window.location.hostname
				+ (window.location.port ? ":" + window.location.port : "");
		if (!jQuery.sap.startsWith(sServiceUrl, sOrigin)) {
			return "proxy/" + sServiceUrl.replace("://", "/");
		} else {
			return sServiceUrl.substring(sOrigin.length);
		}
	}

};


	